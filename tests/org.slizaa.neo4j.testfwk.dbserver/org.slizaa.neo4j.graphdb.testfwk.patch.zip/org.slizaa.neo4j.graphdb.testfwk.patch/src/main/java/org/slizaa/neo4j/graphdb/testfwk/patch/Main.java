package org.slizaa.neo4j.graphdb.testfwk.patch;

public class Main {

  public static void main(String[] args) {

    // @formatter:off
    ServerStarter.startServer("D:/neo4jtemp",  
        "hurz", 
        "D:/50-Development/environments/slizaa-master/git/slizaa-scanner/org.slizaa.scanner/org.slizaa.scanner.itest/target/unittests/1498046949829SimpleJTypeJDKTest");
    // @formatter:on
  }
}
