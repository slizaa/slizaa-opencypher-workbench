package org.slizaa.neo4j.graphdb.testfwk.patch;

import java.io.File;

import org.neo4j.harness.ServerControls;

/**
 * <p>
 * </p>
 *
 * @author Gerd W&uuml;therich (gerd@gerd-wuetherich.de)
 */
public class ServerStarter {

  /** - */
  public static ServerControls _serverControls;
  
  /**
   * <p>
   * </p>
   *
   * @param workingDir
   * @param subDir
   * @return
   */
  public static AutoCloseable startServer(String workingDir, String subDir, String copyFrom) {
    return _serverControls  = new InProcessServerBuilder(new File(workingDir), subDir)
        .copyFrom(new File(copyFrom))
        .newServer();
  }
  
  public static void close() {
    _serverControls.close();  
    _serverControls = null;
  }
}
