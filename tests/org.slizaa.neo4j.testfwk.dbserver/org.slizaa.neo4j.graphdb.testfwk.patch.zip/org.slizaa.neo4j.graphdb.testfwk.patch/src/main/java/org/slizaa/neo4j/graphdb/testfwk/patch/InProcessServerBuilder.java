package org.slizaa.neo4j.graphdb.testfwk.patch;

import static org.neo4j.dbms.DatabaseManagementSystemSettings.database_path;

import java.io.File;
import java.util.Map;

import org.neo4j.harness.ServerControls;
import org.neo4j.harness.internal.AbstractInProcessServerBuilder;
import org.neo4j.kernel.configuration.Config;
import org.neo4j.kernel.impl.factory.GraphDatabaseFacadeFactory.Dependencies;
import org.neo4j.logging.FormattedLogProvider;
import org.neo4j.server.AbstractNeoServer;
import org.neo4j.server.CommunityNeoServer;

/**
 * <p>
 * </p>
 *
 * @author Gerd W&uuml;therich (gerd@gerd-wuetherich.de)
 */
public class InProcessServerBuilder extends AbstractInProcessServerBuilder {

  /** - */
  private File _databaseDirectory;

  /**
   * <p>
   * Creates a new instance of type {@link InProcessServerBuilder}.
   * </p>
   *
   * @param workingDir
   * @param subDir
   */
  public InProcessServerBuilder(File workingDir, String subDir) {
    super(workingDir, subDir);

    //
    _databaseDirectory = new File(workingDir, subDir);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  protected AbstractNeoServer createNeoServer(Map<String, String> config, Dependencies dependencies,
      FormattedLogProvider userLogProvider) {

    //
    config.put(database_path.name(), _databaseDirectory.getAbsolutePath());

    //
    return new CommunityNeoServer(Config.embeddedDefaults(config), dependencies, userLogProvider);
  }
}